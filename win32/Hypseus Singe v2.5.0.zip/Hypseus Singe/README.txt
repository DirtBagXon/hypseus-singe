Hypseus Singe (v2.5.0)
======================

https://github.com/DirtBagXon/hypseus-singe


Hypseus is a fork of Matt Ownby's Daphne.

A program to play laserdisc arcade games on a PC or Raspberry Pi.

This version includes Singe support for Fan Made and American Laser Games.

Features:

Updated MPEG2 decoder
Working MPEG2 x86_64 hw accel (SSE2)
SDL2 support
Digital Leisure overlays
Singe game support
Singe joystick [mouse] support
Psuedo Singe 2 support (details below)
Advanced multi joystick configuration
PNG screenshots


Singe
=====

For Singe, provide the following arguments to hypseus:

hypseus.exe singe vldp -blend_sprites -framefile singe\timegal\timegal.txt -script singe\timegal\timegal.singe 


Singe joystick [mouse] support
==============================

Singe now automatically interprets joystick axis change as mouse movement (Gun Games).

Adjust sensitivity via -js_range <1-20> in Singe arguments.

Configure joystick buttons in hypinput.ini

Extended arguments and keys
===========================

The following additional arguments have been added to Hypseus Singe:

-keymapfile                [ Specify an alternate hypinput.ini file        ]
-alt_osd                   [ Use alternate lair/ace font overlay           ]
-blend_osd                 [ Use TTF blending on alternate font overlay    ]
-nolinear_scale            [ Disable linear scaling [fullscreen]           ]
-nolair2_overlay           [ Disable lair2 text overlay                    ]

-blend_sprites             [ Restore BLENDMODE outline on Singe sprites    ]
-js_range <1-20>           [ Adjust Singe joystick sensitivity: [def:5]    ]

Alt-Enter                  [ Toggle fullscreen                             ]
[KEY_BUTTON3]              [ Toggle scoreboard display in lair/ace         ]

Support
=======

This software intended for educational purposes only. Please submit issues or pull requests directly to the project.

DO NOT submit issues or request support from the official Daphne forums!

About
=====

Open development by the original author, Matt Ownby, ceased years ago.

Singe was created by Scott Duensing as a plugin to Daphne to allow the playing of American Laser Games.

This repository was created to build upon the Hypseus project created by Jeffrey Clark. Many overlays were still unimplemented in the original repository. Singe had also been removed.

The name was changed to Hypseus so the original authors of Daphne would not be burdened with requests for support.

A big thanks goes out to Matt Ownby, Scott Duensing, Jeffrey Clark, Manuel Alfayate, David Griffith and the many other developers who made their work available for me to build upon. Without them this project would not be possible.

License
=======

Hypseus Singe, Super Multiple Arcade Laserdisc Emulator
Copyright (C) 2021 DirtBagXon

Hypseus, Multiple Arcade Laserdisc Emulator
Copyright (C) 2016 Jeffrey Clark

Daphne, the First Ever Multiple Arcade Laserdisc Emulator
Copyright (C) 1999-2013 Matt Ownby

GNU General Public License version 3

This program is free software: you can redistribute it and/or modify
it under the terms of the [GNU General Public License] as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
[GNU General Public License] for more details.

Trademark
=========

The "Hypseus Singe" mark is used to uniquely identify this project as an Arcade Laserdisc Emulator. Any direct or indirect commercial use of the mark "Hypseus" is strictly prohibited without express permission.
